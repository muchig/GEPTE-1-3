<!DOCTYPE html>
<head>
    
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>




    <div class = "login-container">
    <h2>Login</h2>

    <?php
    session_start();
    // include './users.php';
    // require "check.php";
    // if (isset($failed)) {echo "<h3  
    //     style = 
    //     margin: 0 0 30px;
    //     padding: 0;
    //     color: #fff;
    //     text-align: center;>

    //     INVALID USER/PASSWORD

    //     </h3>";}
    // print_r($_SESSION['users']);
    // ?>
    


    <form method="post" action="home.php">
    
    <div class="user-box">
    <input type="text" name="username" required/>
      <label>Username</label>
    </div>
        
    <div class="user-box">
    <input type="password" name="password" required/>
      <label>Password</label>
    </div>



    <div class="loginpos">
    <input type="submit" value="Login" required/>
    </div>
       

    </form>

    <p class="message">Not registered? <a href="register.php">Create an account</a></p>
  
    </div>
   
</body>
</html>