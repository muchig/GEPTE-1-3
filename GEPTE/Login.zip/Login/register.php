<!DOCTYPE html>
<head>
    
    <title>Login Page</title>
    <link rel="stylesheet" href="stylereg.css">
</head>
<body>




    <div class = "login-container">
    <h2>Register</h2>

    <?php
    session_start();
    // include "reg.php";
    // if (isset($failed)) {echo "<h3  
    //     style = 
    //     margin: 0 0 30px;
    //     padding: 0;
    //     color: #fff;
    //     text-align: center;>

    //     INVALID USER/PASSWORD

    //     </h3>";}

    // print_r($_SESSION['users']);
        
    // ?>
    


    <form method="post" action="reg.php">
    
    <div class="user-box">
    <input type="text" name="username" required/>
      <label>Username</label>
    </div>
        
    <div class="user-box">
    <input type="password" name="password" required/>
      <label>Password</label>
    </div>

    <div class="loginpos">
    <input type="submit" value="Register" required/>
    </div>
       

    </form>

    <p class="message">Already have an account? <a href="index.php">Log in</a></p>
  
    </div>



   
</body>
</html>