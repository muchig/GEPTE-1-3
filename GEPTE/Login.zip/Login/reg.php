<?php
// include 'users.php';
session_start();
$username = $_POST['username'];
$password = $_POST['password'];



if (array_key_exists( $username, $_SESSION['users'])){
    header('Location: ./register.php');
}else{
    

    $_SESSION['users'] += [$username => array(
        'password' => $password,
        'img' => 'images/user.jpg'
    )];

    header('Location: ./index.php');
}
?>