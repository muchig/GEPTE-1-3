<?php
    session_start();
    if(!isset($_SESSION["stuno"])) {
        header("Location: login.php");
        exit();
    }
?>