<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="register.php" method="post">

<h2>REGISTER</h2>

<?php
    require('dbconnect.php');

    if (isset($_REQUEST['stuno'])) {

        $stuno = stripslashes($_REQUEST['stuno']);
        $password = stripslashes($_REQUEST['password']);
        $fname    = stripslashes($_REQUEST['fname']);
        $lname    = stripslashes($_REQUEST['lname']);
        $bday    = stripslashes($_REQUEST['bday']);
        $course   = stripslashes($_REQUEST['course']);
        $cnum   = stripslashes($_REQUEST['cnum']);
        $email    = stripslashes($_REQUEST['email']);
        $query    = "INSERT into `infomain` (StudentNumber, NameFirst, NameLast, Bday, Course, ContactNo, Email, password)
                     VALUES ('$stuno', '$fname', '$lname', '$bday', '$course', '$cnum', '$email', '" . md5($password) . "')";
        $result   = mysqli_query($con, $query);
        if ($result) {
            echo "<div class='form'>
                  <h3>You are registered successfully.</h3><br/>
                  
                  </div>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  
                  </div>";
        }
    } else {
?>
    
<?php
    }
?>

<label>Student Number</label>

<input type="text" name="stuno" placeholder="Student Number"><br>

<label>Password</label>

<input type="password" name="password" placeholder="Password"><br>

<label>First Name</label>

<input type="text" name="fname" placeholder="First Name"><br>

<label>Last Name</label>

<input type="text" name="lname" placeholder="Last Name"><br>

<label>Birthday</label>

<input type="text" name="bday" placeholder="Birthday"><br>

<label>Course</label>

<input type="text" name="course" placeholder="Course"><br>

<label>Contact Number</label>

<input type="text" name="cnum" placeholder="Contact Number"><br>

<label>Email</label>

<input type="text" name="email" placeholder="Email"><br>



<button type="submit">Register</button>

<p class='link'>Click here to <a href='login.php'>Login</a></p>

</form>
</body>
</html>